<HTML>
	<HEAD>

		<TITLE>
			Robo-Tech Forum
		</TITLE>

		<meta charset="utf-8">
		<title>particles.js</title>
        <link rel="icon" type="image/jpeg" href="logo.jpeg">
        <link rel="stylesheet" type="text/css" href="inc/css/loader.css">
		<meta name="description" content="particles.js is a lightweight JavaScript library for creating particles.">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <link rel="stylesheet" type="text/css" href="index/index.css">
        <link rel="stylesheet" type="text/css" href="aos/dist/aos.css">
        <link rel="stylesheet" type="text/css" href="inc/css/parallax.css">
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<script src="bootstrap/js/jquery-3.2.1.min.js"></script>
		<script src="bootstrap/js/bootstrap.min.js"></script>
        
		
	</HEAD>
	<BODY>
        <div id="container">
            <div class="row cf">
              <div class="three col">
                <div class="loader" id="loader-2">
                  <span><br>R</span>
                  <span><br>T</span>
                  <span><br>F</span>
                </div>
              </div>
            </div>
          </div>
        <div id="mb">
            <nav class="navbar navbar-default" style="position:fixed; z-index:5; width:100%">
		<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle" >
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
		 
			</div>
			<!-- Collection of nav links and other content for toggling -->
			<div id="navbarCollapse" class="collapse navbar-collapse">
				<ul class="nav navbar-nav" style="color:white;font-size:18px;"  >
					<li class="active"><a href="index.php" >Home<br/></a></li>
					<li><a href="about_us.html">About us<br/></a></li>
                    <li><a href="goal.html">Goals<br/></a></li>
                     <li><a href="gallary.html">Gallery<br/></a></li>
					<li><a href="team.html">Our Team<br/></a></li>
                    <li><a href="workshop.php">Workshops<br/></a></li>
					 <li><a href="sponsor.html">Sponsors<br/></a></li>
                    <li><a href="contact.php">Contact Us<br/></a></li>
				</ul>
			</div>
		</nav>
           
            

            
                <div class="bgimg1" id="particles-js" style="align-content:center">
                    <div style="text-align:center; color:white;position:absolute;top:50%;width:100%;">
                    <span style="background-color:#263238; font-size:30px;padding:20px;font: 30px 'Lato',sans-serif; letter-spacing:7px" id="robotech">THIS IS ROBO-TECH FORUM</span>
                         <span style="background-color:#263238; font-size:30px;padding:20px;font: 30px 'Lato',sans-serif; letter-spacing:7px;" id="rtf">THIS IS RTF</span>
                    </div> 
                    
                     <a href="#nex"><div class="arrow bounce" ></div></a>

                </div><br><br><br>
        <div id="nex">
            <div  class="conainer-fluid" id="noCar"  >
                <div   class="col-sm-6 container" style="padding: 20px;position:relative" >
                    <img src="logo.jpeg" id="img1"  style="position:absolute;left:0px;right:0px;margin:auto;width:auto">
                </div>
				<div id="para1" class="col-sm-6 container" style="padding: 20px"  >
					<h1>Robotics and Automation</h1>
					<p>Robo-tech Forum was founded to inculcate a culture of robotics and automation in GCOEA to solve real-world problems. Also, to help our students achieve credible skill in designing and developing robust autonomous machines for the future and create an environment of research and development in robotics. </p>
                    <a href="about_us.html"><button class="btn-primary container col-sm-12" id="btn1" ><h4 style="margin:0px">Learn more</h4></button></a>
                </div>
            </div>
        <div id="car" class="carousel slide" data-ride="carousel">
            
            <div class="carousel-inner">
                <div class="item active"><img id="para11" src="logo.jpeg" style=" padding:20px;left:0px;right:0px;margin:auto;width:auto"></div>
                <div  class="item" style="height: 360px;padding:20px;">
                 <h1>Robotics and Automation</h1>
					<p>Robo-tech Forum was founded to inculcate a culture of robotics and automation in GCOEA to solve real-world problems. Also, to help our students achieve credible skill in designing and developing robust autonomous machines for the future and create an environment of research and development in robotics. </p>
                    <button class="btn-primary container col-sm-12" id="btn1" ><h4 style="margin:0px"><a href="about_us.html">Learn more</a></h4></button>
                </div>
                
                <a class="left carousel-control" href="#car" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="rigth carousel-control" href="#car" data-slide="next" style="right: 0px">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    <span class="sr-only">Next</span>
                </a>
                
            </div>
            
        </div>
                
            </div><br><br><br>

        <div class="bgimg2" ></div><br><br><br>
          
        <div class=" iframe">
                <div class="col-sm-6 actdiv"  >
                <img src="pics/697bc8_b091c675b03946a0b6fc0079ca8ce9a7-mv2_d_1510_1438_s_2.png" class="img-responsive actimg">
            </div>
           <div class="col-sm-6" id="paradiv"  style="margin-bottom:30px ">
                <h1>Activities:-</h1>
                <p style="padding:0px">RTF team represents GCOEA in various national and international level competitions, provide guidance to student in major and minor projects and conduct workshop on industry oriented softwares such as CATIA, PTC Creo and MATLAB</p>
               
               <div id="myCarousel" class="carousel slide" data-ride="carousel">
                        <!-- Indicators -->
                      <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
                        <li data-target="#myCarousel" data-slide-to="2"></li>
                      </ol>

                      <!-- Wrapper for slides -->
                      <div class="carousel-inner">
                        <div class="item active">
                          <img src="pics/mechatronics2.jpg" alt="mechatronics">
                        </div>

                        <div class="item">
                          <img src="pics/matlab2.jpg" alt="matlab">
                        </div>

                        <div class="item">
                          <img src="pics/pcb2.jpg" alt="pcb">
                        </div>
                      </div>

                      <!-- Left and right controls -->
                      <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                        <span class="sr-only">Previous</span>
                      </a>
                      <a class="right carousel-control" href="#myCarousel" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                        <span class="sr-only">Next</span>
                      </a>
                </div>
               
               <p style="padding:0px">The Robo-Tech Forum was formed in September, 2013 when seven students from four different branches took the initiative. The forum is guided by Prof. P.L. Paikrao, Department of Electronics and Telecommunication Engineering and various professors from seven different branches</p>
                  <a href="goal.html"><button class="btn-primary container col-sm-12" id="btn1" ><h4 style="margin:0px">learn more</h3></button></a>
            </div>
          </div>
        
   <br><br><br><hr><br><br><br>
     <div class="container gridcont" id="griddiv">
                <img class=" img-responsive" src="pics/grid.jpg" style="position:absolute;left:0px;right:0px;margin:auto;border-style:groove;border-width:10px;border-color:lightseagreen" id="gridimg">
            <a href="gallary.html" style="margin:0px"><div class=" img-responsive" style="position:absolute;background-color:#00838F;left:0px;right:0px;margin:auto;border-style:groove;border-width:10px;border-color:lightseagreen" id="gal">
                <h1 style="color:white; position:absolute;top:40%;left:0px;right:0px;margin:auto;text-align:center ">Click Here To visit Gallery</h1>
            </div></a>
   
         </div><br><br><br>
       <footer> 
                 <div class="col-sm-8" id="googleMap" ></div>

                 <div class="col-sm-4 container" style="background-color:#424242;" id="footer-div">   
                    
                    <div style="padding:10%;padding-bottom:5%;font-family:'Comic Sans MS',cursive, sans-serif;}">
                        Contact:<br><br>Abhilash Ingle<br/>Email: abhilashingale08@gmail.com<br/>contact no. :+919421034820
                        <br><br>Anmol Lal<br> Email: lal.anmol01@gmail.com <br> Contact No. :+918551949013
                    </div>
                     <div style="position:relative; ">
                        <a href="https://www.facebook.com/robotechforum/" target="_blank"><img src="pics/fb.png" class="img2" /></a>
                         <a href="https://www.linkedin.com/company-beta/13366701/" target="_blank"><img src="pics/linkedin.png" class="img2" /></a>
                    </div>
                     <br><br><br>
                     <h6 style="padding:10px;margin:0px;font-size:10px">Credits:<br>Developer - Saurish Darodkar</h6>
                </div>
           
            
		</footer>  
        </div>
        
		
        
        
		
        <script>
            window.onload = function() {
                 document.getElementById("container").style.display='none';
                 document.getElementsByClassName("bgimg2")[0].style.backgroundImage = 'url(inc/css/bot2.jpeg)';
                 AOS.init({easing :'ease-in-out-sine',
                duration: 1200,         
            });
                 $("#img1").height($("#para1").height()) ;

                $("#nocar").height($("#para1").height()+30) ;
                $("#car").height($("#para11").height()+30) ;
                $("#gal").height($("#gridimg").height());
                 $("#griddiv").height($("#gridimg").height());
                document.getElementById("griddiv").style.height = document.getElementById('gridimg').offsetHeight;
                if(screen.width<=750){
                     $("#nex").height($("#car").height());
                }
                else{
                     $("#nex").height($("#para1").height()+20);
                }
               
            }
            
            
        
        </script>
                 <script>
                function myMap() {
                var mapProp= {
                    center:new google.maps.LatLng(20.957211,77.75679979999995),
                    zoom:15,
                };
                var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
                }
                </script>

                <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBZSL_f8fCgzrD2BbBoK4gRvS785HLtv_c&callback=myMap"></script>
        
		<script src="particles/particles.js"></script>
        <script src="aos/dist/aos.js"></script>
		<script src="js/app.js"></script>
       
		<script>
            
			
           
            
           
      
            
             $(document).ready(function(){
              // Add smooth scrolling to all links
              $("a").on('click', function(event) {

                // Make sure this.hash has a value before overriding default behavior
                if (this.hash !== "") {
                  // Prevent default anchor click behavior
                  event.preventDefault();

                  // Store hash
                  var hash = this.hash;

                  // Using jQuery's animate() method to add smooth page scroll
                  // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
                  $('html, body').animate({
                    scrollTop: $(hash).offset().top
                  }, 800, function(){

                    // Add hash (#) to URL when done scrolling (default click behavior)
                    window.location.hash = hash;
                  });
                } // End if
              });
            });
            
		</script>

		<!-- stats.js -->
		<script src="js/lib/stats.js"></script>
       
        
		
	</BODY>
</HTML>